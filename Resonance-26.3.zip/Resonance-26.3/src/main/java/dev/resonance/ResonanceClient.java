package dev.resonance;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;

import java.util.HashSet;
import java.util.Set;

/**
 * Client-only, mixin-free sound enhancer. It only READS player state each tick
 * and plays its own sounds, so it cannot conflict with other mods.
 */
public class ResonanceClient implements ClientModInitializer {
    public static final String ID = "resonance";

    static final SoundEvent HEARTBEAT = Compat.sound("heartbeat");
    static final SoundEvent BURNING   = Compat.sound("burning");
    static final SoundEvent SNEAK     = Compat.sound("sneak");
    static final SoundEvent LAND      = Compat.sound("land");
    static final SoundEvent LEVEL_UP  = Compat.sound("level_up");
    static final SoundEvent EFFECT    = Compat.sound("effect_gain");
    static final SoundEvent ARMOR     = Compat.sound("armor_equip");
    static final SoundEvent BOW_DRAW  = Compat.sound("bow_draw");
    static final SoundEvent BOW_SHOOT = Compat.sound("bow_shoot");
    static final SoundEvent SWAP      = Compat.sound("item_swap");
    static final SoundEvent HUNGER    = Compat.sound("hunger");
    static final SoundEvent SPLASH    = Compat.sound("splash");
    static final SoundEvent USE_START = Compat.sound("use_start");
    static final SoundEvent SHIELD_UP = Compat.sound("shield_up");
    static final SoundEvent DRINK     = Compat.sound("drink");

    private int lastSlot = -1, lastLevel = -1, burnCd, heartCd, hungerCd, swapCd, drawTicks;
    private boolean wasSneaking, wasOnGround = true, wasUsing, wasDrawing, wasInWater;
    private double prevVy;
    private final Set<Object> effects = new HashSet<>();
    private final Object[] armor = new Object[4];
    private static final EquipmentSlot[] SLOTS =
        {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private static void play(SoundEvent e, float vol, float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(e, pitch, vol));
    }

    private void reset() {
        lastSlot = lastLevel = -1; swapCd = 0; drawTicks = 0;
        wasSneaking = false; wasOnGround = true; wasUsing = false; wasDrawing = false; wasInWater = false;
        effects.clear(); java.util.Arrays.fill(armor, null);
    }

    private void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { reset(); return; }
        boolean first = lastSlot == -1;

        // heartbeat below 2 hearts
        if (heartCd > 0) heartCd--;
        if (p.isAlive() && p.getHealth() <= 4.0f && heartCd == 0) { play(HEARTBEAT, 0.8f, 1f); heartCd = 40; }

        // hungry stomach growl
        if (hungerCd > 0) hungerCd--;
        if (p.isAlive() && p.getFoodData().getFoodLevel() <= 6 && hungerCd == 0) { play(HUNGER, 0.5f, 1f); hungerCd = 600; }

        // splash when entering water
        boolean iw = p.isInWater();
        if (iw && !wasInWater && !first) play(SPLASH, 0.6f, 0.95f + p.getRandom().nextFloat() * 0.1f);
        wasInWater = iw;

        // burning
        if (burnCd > 0) burnCd--;
        if (p.isOnFire() && burnCd == 0) { play(BURNING, 0.5f, 1f); burnCd = 30; }

        // sneak start
        boolean sn = p.isShiftKeyDown();
        if (sn && !wasSneaking && !first) play(SNEAK, 0.3f, 1.1f);
        wasSneaking = sn;

        // landing after a fall
        boolean og = p.onGround();
        if (og && !wasOnGround && prevVy < -0.55) {
            float v = (float) Math.min(1.0, -prevVy / 1.5);
            play(LAND, v, 0.9f + p.getRandom().nextFloat() * 0.2f);
        }
        wasOnGround = og; prevVy = p.getDeltaMovement().y;

        // level up
        int lvl = p.experienceLevel;
        if (lastLevel != -1 && lvl > lastLevel) play(LEVEL_UP, 0.8f, 1f);
        lastLevel = lvl;

        // hotbar swap: only while playing (no menu open), with a cool-down so
        // fast scrolling or other mods moving the slot can't spam the sound
        if (swapCd > 0) swapCd--;
        int slot = p.getInventory().getSelectedSlot();
        if (lastSlot != -1 && slot != lastSlot && mc.screen == null && swapCd == 0
                && !p.getMainHandItem().isEmpty() && !p.isUsingItem()) {
            play(SWAP, 0.35f, 0.95f + p.getRandom().nextFloat() * 0.1f);
            swapCd = 6;
        }
        lastSlot = slot;

        // new potion effects
        Set<Object> now = new HashSet<>(p.getActiveEffectsMap().keySet());
        if (!first) for (Object o : now) if (!effects.contains(o)) { play(EFFECT, 0.6f, 1f); break; }
        effects.clear(); effects.addAll(now);

        // armor equipped
        for (int i = 0; i < 4; i++) {
            var st = p.getItemBySlot(SLOTS[i]);
            Object cur = st.isEmpty() ? null : st.getItem();
            if (!first && cur != null && cur != armor[i]) play(ARMOR, 0.6f, 1f);
            armor[i] = cur;
        }

        // using an item: a sound when the use STARTS, depending on the item
        boolean using = p.isUsingItem();
        var use = p.getUseItem();
        boolean drawing = using && (use.is(Items.BOW) || use.is(Items.TRIDENT));
        if (using && !wasUsing) {
            if (drawing || use.is(Items.CROSSBOW)) play(BOW_DRAW, 0.6f, 1f);
            else if (use.is(Items.SHIELD)) play(SHIELD_UP, 0.6f, 1f);
            else if (use.is(Items.POTION) || use.is(Items.MILK_BUCKET)) play(DRINK, 0.5f, 1f);
            else play(USE_START, 0.4f, 0.95f + p.getRandom().nextFloat() * 0.1f);
        }
        wasUsing = using;

        // release sound for bow / trident, only if it was really drawn
        if (drawing) drawTicks++;
        else {
            if (wasDrawing && drawTicks >= 5) play(BOW_SHOOT, 0.7f, 1f);
            drawTicks = 0;
        }
        wasDrawing = drawing;
    }
}
