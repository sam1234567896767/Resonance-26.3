<p align="center"><img src="logo_banner.png"></p>

# Resonance 26.3 (Soundify alternative)
Client-only, mixin-free Fabric mod. Original code; no Soundify assets used.
Sounds: heartbeat, burning, sneak, hard landing, level up, effect gained, armor equip, bow draw/shot, item swap.

## Build (this project = Minecraft 26.3 only)
1. Fill `loader_version` / `fabric_api_version` in gradle.properties from https://fabricmc.net/develop.
2. JDK 25, then run `gradle build`. The jar is in build/libs/ (use the one WITHOUT -sources).
   No local setup? Push this folder to GitHub: the included Actions workflow builds the jar for you.
## Custom sounds
Default sounds reuse vanilla events. To use your own, put .ogg files in
assets/resonance/sounds/ and point sounds.json at them (e.g. {"name":"resonance:heartbeat"}),
or ship them in a resource pack.

## Compatibility
Client-side, no mixins, no server needed; it only reads player state, so it doesn't patch other mods' code.
